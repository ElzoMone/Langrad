/* Langrad Importer 0.3: user-activated import, no website crawling or network proxies. */
chrome.runtime.onMessage.addListener((msg,sender,respond)=>{
 if(msg?.type!=="LANGRAD_IMPORT_PAGE")return;
 importArticle(msg.tabId).then(info=>respond({ok:true,...info}),e=>respond({ok:false,error:e.message||String(e)}));
 return true;
});
async function importArticle(tabId){
 if(!Number.isInteger(tabId))throw Error("Открой страницу статьи в обычной вкладке браузера.");
 const result=await chrome.scripting.executeScript({target:{tabId},func:readLangradArticle});
 const data=result?.[0]?.result;
 if(!data?.text||data.text.trim().length<25)throw Error("Не удалось найти текст статьи. Выдели фрагмент на странице.");
 const tab=await chrome.tabs.create({url:"https://langrad.vercel.app/#import-from-extension",active:true});
 await new Promise((resolve,reject)=>{
  let done=false;
  const finish=e=>{if(done)return;done=true;clearTimeout(timer);chrome.tabs.onUpdated.removeListener(updated);chrome.tabs.onRemoved.removeListener(closed);e?reject(e):resolve()};
  const updated=(id,change)=>{if(id===tab.id&&change.status==="complete")finish()};
  const closed=id=>{if(id===tab.id)finish(Error("Вкладка Langrad закрылась"))};
  const timer=setTimeout(()=>finish(Error("Langrad слишком долго открывается")),25000);
  chrome.tabs.onUpdated.addListener(updated);
  chrome.tabs.onRemoved.addListener(closed);
  chrome.tabs.get(tab.id).then(info=>{if(info.status==="complete")finish()}).catch(()=>{});
 });
 await chrome.scripting.executeScript({target:{tabId:tab.id},world:"MAIN",func:data=>window.dispatchEvent(new CustomEvent("langrad:extension-import",{detail:data})),args:[data]});
 return {count:data.text.length,paragraphs:data.paragraphs};
}

function readLangradArticle(){
 const MAX=65000;
 const trim=s=>String(s||"").replace(/\u00a0/g," ").replace(/[ \t]+/g," ").replace(/\n[ \t]+/g,"\n").trim();
 const selected=trim(window.getSelection()?.toString()||"");
 const title=trim(document.querySelector("#firstHeading,.mw-page-title-main,article h1,main h1,h1")?.textContent||
  document.querySelector('meta[property="og:title"]')?.content||document.title||"Импортированный текст").slice(0,180);
 const url=location.href.slice(0,2000);
 if(selected.length>=20)return{title,text:selected.slice(0,MAX),url,selection:true,paragraphs:1};
 const wiki=/(^|\.)wikipedia\.org$/.test(location.hostname);
 const blocked="script,style,noscript,nav,footer,header,aside,form,button,input,textarea,select,iframe,svg,canvas,video,audio,.navbox,.infobox,.toc,.mw-references-wrap,.reflist,.reference,.references,.mw-editsection,.sidebar,.comments,.comment,.cookie,.advertisement,.advert,.related,.share,.social,[hidden],[aria-hidden='true'],[role='navigation'],[role='banner'],[role='complementary'],#toc,.vector-page-toolbar,.vector-toc,.mw-portlet,.product-list,.recommendations";
 const roots=wiki?[
 "#mw-content-text .mw-parser-output","#mw-content-text",".mw-parser-output","article","main"
 ]:[
 "article [itemprop='articleBody']","[itemprop='articleBody']",
 "main article","article",".article-body",".post-content",".entry-content",
 ".article-content","[role='article']","main [role='main']","main"
 ];
 function gather(root){
  if(!root)return null;
  const tags=wiki?"p,h2,h3,h4,blockquote":"p,h2,h3,h4,blockquote,li";
  const items=root.querySelectorAll(tags);
  let lines=[],total=0,paragraphs=0;
  for(const node of items){
   if(node.closest(blocked))continue;
   if(node.matches("li")&&node.closest("li")!==node)continue;
   if(node.matches("p")&&node.closest("li")&&!wiki)continue;
   // Article body: avoid menus, cards, comments and paid-content previews.
   const line=trim(node.textContent).replace(/\[(?:\d+(?:,\s*\d+)*|Bearbeiten|edit)\]/gi,"").trim();
   if(line.length<18||line.length>16000)continue;
   if(node.matches("p,blockquote"))paragraphs++;
   if(!wiki&&node.matches("li")&&line.length<55)continue;
   if(lines.length&&lines[lines.length-1]===line)continue;
   // Keep paragraphs together: don't insert blank lines inside a paragraph.
   const take=line.slice(0,MAX-total);
   if(!take)break;
   lines.push(take);total+=take.length+2;
   if(total>=MAX)break;
  }
  return {text:lines.join("\n\n").slice(0,MAX),length:total,paragraphs,blocks:lines.length};
 }
 let best=null;
 for(const sel of roots){
  const nodes=[...document.querySelectorAll(sel)].slice(0,5);
  for(const node of nodes){
   const result=gather(node);
   if(!result)continue;
   // A page with long lists but no actual paragraphs is not a readable article.
   const enough=result.length>=Math.min(220,MAX)&&result.paragraphs>=2;
   if(!enough)continue;
   if(!best||result.length>best.length||(wiki&&result.paragraphs>best.paragraphs))best=result;
  }
  if(best&&(wiki?best.length>400:best.length>1200))break;
 }
 if(!best||best.text.length<150)throw new Error("Не удалось найти основную статью. Выдели нужный текст мышкой и повтори импорт.");
 return {title,text:best.text,url,selection:false,paragraphs:best.paragraphs};
}